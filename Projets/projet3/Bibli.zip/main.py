import subprocess
import sys
from tkinter import *
from tkinter import messagebox
from tkinter import filedialog
from tkinter import ttk
from PIL import Image, ImageTk
from io import BytesIO
from datetime import date, timedelta
import sqlite3
import requests
import datetime

#subprocess.check_call([sys.executable, "-m", "pip", "install", "Pillow"])
#subprocess.check_call([sys.executable, "-m", "pip", "install", "requests"])

bdd = ""

date_ajd = date.today().strftime("%Y-%m-%d")

def sms_auto(numero, message):
    numero_tel = numero[1:]
    numero_tel = "+33" + numero_tel

    resp = requests.post('https://textbelt.com/text', {
        'phone': numero_tel,
        'message': message,
        'key': 'textbelt',
    })

def verif_date_sms():
    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()

    cursor.execute("SELECT date_retour FROM Emprunts")
    rows = cursor.fetchall()

    cursor.close()
    conn.close()

    for row in rows:
        date_retour = row[0]
        date_retour = datetime.datetime.strptime(date_retour, "%Y-%m-%d").date()
        date_7_jours_avant = date_retour - timedelta(weeks=1)

        if date_7_jours_avant == datetime.datetime.strptime(date_ajd, "%Y-%m-%d").date():
            conn = sqlite3.connect(bdd)
            cursor = conn.cursor()

            cursor.execute("SELECT nom_emprunteur, numero_tel, Livres.titre FROM Emprunts INNER JOIN Livres ON Emprunts.livre_isbn = Livres.isbn")
            resultats = cursor.fetchall()

            cursor.close()
            conn.close()

            for infos in resultats:
                sms_auto(infos[1], "Rappel: {}, {} doit être retourné dans 1 semaine à la bibliothèque. Merci de votre coopération.".format(infos[0], infos[2]))
        
        elif date_retour == datetime.datetime.strptime(date_ajd, "%Y-%m-%d").date():
            conn = sqlite3.connect(bdd)
            cursor = conn.cursor()

            cursor.execute("SELECT nom_emprunteur, numero_tel, Livres.titre FROM Emprunts INNER JOIN Livres ON Emprunts.livre_isbn = Livres.isbn")
            resultats = cursor.fetchall()

            cursor.close()
            conn.close()

            for infos in resultats:
                sms_auto(infos[1], "Rappel: {}, {} doit être retourné ajourd'hui à la bibliothèque. Merci de votre coopération.".format(infos[0], infos[2]))
    
    ecran_de_chargement.destroy()

trigger_ajout_emprunt = """
    CREATE TRIGGER update_emprunt
    AFTER INSERT ON Emprunts
    FOR EACH ROW
    BEGIN
        UPDATE Livres
        SET emprunt = 1
        WHERE Livres.isbn = NEW.livre_isbn;
    END;
"""

trigger_supp_emprunt = """
    CREATE TRIGGER update_retour
    AFTER DELETE ON Emprunts
    FOR EACH ROW
    BEGIN
        UPDATE Livres
        SET emprunt = 0
        WHERE Livres.isbn = OLD.livre_isbn;
    END;
"""

def ouvrir_fichier():
    global bdd, ecran_de_chargement
    bdd = filedialog.askopenfilename()

    if not bdd.endswith(".db"):
        messagebox.showerror("Erreur", "Le fichier sélectionné n'est pas une base de données SQLite.")
        return
    else:
        messagebox.showinfo("Ouvrir", "Bdd ouverte avec succès.")

    ouvrir.grid_forget()
    creer.grid_forget()

    ecran_de_chargement = Toplevel()
    ecran_de_chargement.title("Chargement")
    ecran_de_chargement.geometry("300x100")
    ecran_de_chargement.grab_set()

    Label(ecran_de_chargement, text="Envoie des rappels en cours...").pack()

    ecran_de_chargement.after(100, verif_date_sms)

    global lecture_isbn

    Label(page_principale, text="Isbn:").pack()
    lecture_isbn = Entry(page_principale)
    lecture_isbn.pack()

    Button(page_principale, text="Valider", command=lecture).pack()

def infos_livre(isbn):
    global titre, auteur, editeur, date_de_publi, nbm_page, resume, couverture

    requete = requests.get("https://www.googleapis.com/books/v1/volumes?q=isbn:{}".format(isbn))
    donnees = requete.json()
    
    if "items" in donnees:
        items = donnees["items"][0]
        infos = items["volumeInfo"]
        
        titre = infos.get("title", "Titre inconnu")
        auteur = infos.get("authors", "Auteur inconnu")[0]
        editeur = infos.get("publisher", "Éditeur inconnu").strip("{}")
        date_de_publi = infos.get("publishedDate", "Date de publication inconnue")
        nbm_page = infos.get("pageCount", "Nombre de page inconnu")
        resume = infos.get("description", "Résumé indisponible")
        if "imageLinks" in infos:
            couverture = infos["imageLinks"]["thumbnail"]
        else:
            couverture = "Couverture indisponible"
    else:
        messagebox.showinfo("Erreur", "Aucune information trouvée pour cet ISBN.")
    
    fenetre_attente_scan.destroy()

    entre_titre.delete(0, END)
    entre_titre.insert(0, titre)

    entre_annee.delete(0, END)
    entre_annee.insert(0, date_de_publi)

    entre_isbn.delete(0, END)
    entre_isbn.insert(0, isbn)

    entre_resume.delete(0, END)
    entre_resume.insert(0, resume)

    entre_page.delete(0, END)
    entre_page.insert(0, str(nbm_page))

    entre_couverture.delete(0, END)
    entre_couverture.insert(0, couverture)

def lecture():
    global isbn_pour_emprunt

    status = Label(page_principale, text="")
    status.pack(side=TOP)

    cadre_boutons = Frame(page_principale)
    cadre_boutons.pack(side=TOP)

    Button(cadre_boutons, text="Emprunter", command=afficher_emprunter).grid(row=0, column=0, padx=5, pady=5)
    Button(cadre_boutons, text="Rendre", command=rendre_livre).grid(row=0, column=2, padx=5, pady=5)
    Button(cadre_boutons, text="Note/Avis", command=afficher_avis).grid(row=1, column=1, padx=5, pady=5)

    image_par_defaut = Image.open("visuel-indisponible.png")
    image_par_defaut = ImageTk.PhotoImage(image_par_defaut)

    isbn = lecture_isbn.get()
    isbn_pour_emprunt = isbn

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()

    cursor.execute("SELECT Livres.*, Auteurs.nom FROM Livres INNER JOIN Auteurs ON Livres.auteur_id = Auteurs.id WHERE isbn = ?", (isbn,))
    livre = cursor.fetchone()
    cursor.execute("SELECT emprunt FROM Livres WHERE isbn = ?", (isbn,))
    dispo = cursor.fetchone()

    cursor.close()
    conn.close()

    if livre:
        infos = "Titre : " + str(livre[1]) + "\n\nAnnée : " + str(livre[2]) + "\n\nAuteur : " + str(livre[8]) + "\n\nNombre de pages : " + str(livre[4]) + "\n\nRésumé : " + str(livre[5]) + "\n\nCouverture : " + str(livre[6])

        if str(livre[6]) != "Couverture indisponible":
            reponse = requests.get(str(livre[6]))
            donnees_image = Image.open(BytesIO(reponse.content))
            image = donnees_image.resize((donnees_image.width*3, donnees_image.height*3), Image.Resampling.NEAREST)
            image = ImageTk.PhotoImage(image)
        else:
            image = image_par_defaut

        if hasattr(page_principale, "image_couverture"):
            page_principale.image_couverture.configure(image=image)
            page_principale.image_couverture.image = image
        else:
            image_couverture = Label(page_principale, image=image)
            image_couverture.pack(side=RIGHT)
            page_principale.image_couverture = image_couverture
            page_principale.image_couverture.image = image

        if hasattr(page_principale, "infos_livre"):
            page_principale.infos_livre.delete(1.0, END)
            page_principale.infos_livre.insert(END, infos)
        else:
            page_principale.infos_livre = Text(page_principale, wrap=WORD, font=("Helvetica", 30))
            page_principale.infos_livre.insert(END, infos)
            page_principale.infos_livre.pack(side=LEFT)

        if dispo[0] == 1:
            status.config(text="Status : Emprunté", fg="red")
        else:
            status.config(text="Status : Disponible", fg="green")
    else:
        messagebox.showerror("Erreur", "Aucun livre trouvé pour cet ISBN.")

    lecture_isbn.delete(0, END)

def nom_bdd():
    def creer_bdd():
        nom = nom_bdd.get()

        if nom == "":
            return messagebox.showerror("Erreur", "Aucun nom pour la base de données.")

        nom = nom + ".db"

        conn = sqlite3.connect(nom)
        cursor = conn.cursor()

        cursor.execute("CREATE TABLE Auteurs (id INTEGER PRIMARY KEY AUTOINCREMENT, nom TEXT NOT NULL, biographie TEXT NOT NULL)")
        cursor.execute("CREATE TABLE Livres (isbn INTEGER PRIMARY KEY, titre TEXT NOT NULL, annee DATE NOT NULL, auteur_id INTEGER NOT NULL, nbm_page INTEGER NOT NULL, resume TEXT, couverture TEXT, emprunt INT DEFAULT 0, FOREIGN KEY (auteur_id) REFERENCES Auteurs(id))")
        cursor.execute("CREATE TABLE Emprunts (livre_isbn INTEGER PRIMARY KEY NOT NULL, nom_emprunteur TEXT NOT NULL, numero_tel TEXT NOT NULL, date_emprunt DATE NOT NULL, jours_emprunt INT NOT NULL, date_retour DATE NOT NULL, FOREIGN KEY (livre_isbn) REFERENCES Livres(isbn))")
        cursor.execute(trigger_ajout_emprunt)
        cursor.execute(trigger_supp_emprunt)
        
        conn.commit()

        cursor.close()
        conn.close()

        messagebox.showinfo("Création", "La bdd a été créée avec succès !")
        fenetre_creation_bdd.destroy()

    fenetre_creation_bdd = Toplevel()
    fenetre_creation_bdd.title("Création de la bdd")

    Label(fenetre_creation_bdd, text="Nom de la bdd:").pack()
    nom_bdd = Entry(fenetre_creation_bdd)
    nom_bdd.pack()

    Button(fenetre_creation_bdd, text="Valider", command=creer_bdd).pack()

def fenêtre_a_propos():
    fenêtre_a_propos = Toplevel()
    fenêtre_a_propos.title("A propos")
    label_a_propos = Label(fenêtre_a_propos, text="Made by Paolino, Boemire and Letrude.")
    label_a_propos.pack(padx=10, pady=10)

def afficher_page_principale():
    ajouter.pack_forget()
    modifier.pack_forget()
    supprimer.pack_forget()
    emprunt.pack_forget()
    page_principale.pack()

def afficher_avis():
    requete = requests.get("https://www.googleapis.com/books/v1/volumes?q=isbn:{}".format(isbn_pour_emprunt))
    donnees = requete.json()
    
    if "reviews" in infos:
        items = donnees["items"][0]
        infos = items["volumeInfo"]

        avis = infos["reviews"]
    else:
        messagebox.showinfo("Erreur", "Aucune note/avis trouvé pour cet ISBN.")

    google_books_frame = Toplevel()
    google_books_label = Label(google_books_frame, text="Avis Google Books")
    google_books_label.pack()
    for review in avis:
        review_label = Label(google_books_frame, text=review)
        review_label.pack()

infos_ajoute_livre = False

def afficher_ajouter_livre():
    global infos_ajoute_livre

    if bdd == "":
        return messagebox.showinfo("Erreur", "Aucune bdd ouverte.")
    page_principale.pack_forget()
    supprimer.pack_forget()
    modifier.pack_forget()
    emprunt.pack_forget()
    ajouter.pack()

    affichage_attente_scan()

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()
    
    cursor.execute("SELECT id, nom FROM Auteurs")
    rows = cursor.fetchall()
    id_noms_prenoms_auteurs = [row for row in rows]
    
    cursor.close()
    conn.commit()
    conn.close()

    def infos_ajouter_livre():
        global entre_titre, entre_annee, liste_auteurs, entre_isbn, entre_resume, entre_page, entre_couverture

        Label(ajouter, text="Titre:").pack()
        entre_titre = Entry(ajouter)
        entre_titre.pack()

        Label(ajouter, text="Année de publication:").pack()
        entre_annee = Entry(ajouter)
        entre_annee.pack()

        Label(ajouter, text="Auteur:").pack()
        id_noms_prenoms_auteurs.insert(0, "Ajouter un nouvel auteur")
        liste_auteurs = ttk.Combobox(ajouter, values=id_noms_prenoms_auteurs, state="readonly")
        liste_auteurs.current(0)
        liste_auteurs.pack()

        Label(ajouter, text="Isbn:").pack()
        entre_isbn = Entry(ajouter)
        entre_isbn.pack()

        Label(ajouter, text="Nombre de page:").pack()
        entre_page = Entry(ajouter)
        entre_page.pack()

        Label(ajouter, text="Lien vers l'image de couverture:").pack()
        entre_couverture = Entry(ajouter)
        entre_couverture.pack()

        Label(ajouter, text="Résumé:").pack()
        entre_resume = Entry(ajouter)
        entre_resume.pack()

        Button(ajouter, text="Ajouter le livre", command=ajouter_livre).pack()
        Button(ajouter, text="Retour", command=afficher_page_principale).pack()
    
    if infos_ajoute_livre == False:
        infos_ajouter_livre()
        infos_ajoute_livre = True

def afficher_ajouter_auteur():
    global fenetre_nouvel_auteur
    fenetre_nouvel_auteur = Toplevel()
    fenetre_nouvel_auteur.title("Ajouter un nouvel auteur")

    global nom_auteur, biographie_auteur

    Label(fenetre_nouvel_auteur, text="Nom:").pack()
    nom_auteur = Entry(fenetre_nouvel_auteur)
    nom_auteur.pack()

    Label(fenetre_nouvel_auteur, text="Biographie:").pack()
    biographie_auteur = Entry(fenetre_nouvel_auteur)
    biographie_auteur.pack()
    
    nom_auteur.delete(0, END)
    nom_auteur.insert(0, auteur)
    
    Button(fenetre_nouvel_auteur, text="Valider", command=ajouter_livre_plus_auteur).pack()

def affichage_attente_scan():
    global fenetre_attente_scan

    fenetre_attente_scan = Toplevel()
    fenetre_attente_scan.title("En attente d'un scan")
    fenetre_attente_scan.geometry("200x200")
    fenetre_attente_scan.grab_set()

    Label(fenetre_attente_scan, text="Isbn:").pack()
    scan_isbn = Entry(fenetre_attente_scan)
    scan_isbn.pack()

    Button(fenetre_attente_scan, text="Valider", command=lambda: infos_livre(scan_isbn.get())).pack()

def afficher_modifier():
    if bdd == "":
        return messagebox.showinfo("Erreur", "Aucune bdd ouverte.")
    page_principale.pack_forget()
    supprimer.pack_forget()
    ajouter.pack_forget()
    emprunt.pack_forget()
    modifier.pack()

    for widget in modifier.winfo_children():
        widget.destroy()

    Button(modifier, text="Modifier un livre", command=modifier_livre).pack()
    Button(modifier, text="Modifier un auteur", command=modifier_auteur).pack()
    Button(modifier, text="Modifier un emprunt", command=modifier_emprunter).pack()

    Button(modifier, text="Retour", command=afficher_page_principale).pack()

def afficher_supprimer():
    if bdd == "":
        return messagebox.showinfo("Erreur", "Aucune bdd ouverte.")
    page_principale.pack_forget()
    ajouter.pack_forget()
    modifier.pack_forget()
    emprunt.pack_forget()
    supprimer.pack()

    for widget in supprimer.winfo_children():
        widget.destroy()

    Button(supprimer, text="Supprimer un livre", command=supprimer_livre).pack()
    Button(supprimer, text="Supprimer un auteur", command=supprimer_auteur).pack()
    Button(supprimer, text="Supprimer un emprunt", command=supprimer_emprunter).pack()

    Button(supprimer, text="Retour", command=afficher_page_principale).pack()

infos_ajoute_emprunt = False

def afficher_emprunter():
    global infos_ajoute_emprunt

    isbn = isbn_pour_emprunt

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()

    cursor.execute("SELECT emprunt FROM Livres WHERE isbn = ?", (isbn,))
    resultat = cursor.fetchone()

    conn.commit()
    cursor.close()
    conn.close()

    if resultat[0] == 1:
        messagebox.showinfo("Erreur", "Ce livre est déjà emprunté.")
        return

    page_principale.pack_forget()
    supprimer.pack_forget()
    ajouter.pack_forget()
    modifier.pack_forget()
    emprunt.pack()

    def infos_ajouter_emprunt():
        global entre_isbn_emprunt, entre_nom_emprunteur, entre_numero_tel, entre_date_emprunt, entre_semaines_emprunt

        Label(emprunt, text="Isbn du livre:").pack()
        entre_isbn_emprunt = Entry(emprunt)
        entre_isbn_emprunt.pack()

        Label(emprunt, text="Nom de l'emprunteur:").pack()
        entre_nom_emprunteur = Entry(emprunt)
        entre_nom_emprunteur.pack()

        Label(emprunt, text="Numéro de téléphone:").pack()
        entre_numero_tel = Entry(emprunt)
        entre_numero_tel.pack()

        Label(emprunt, text="Date d'emprunt:").pack()
        entre_date_emprunt = Entry(emprunt)
        entre_date_emprunt.pack()

        Label(emprunt, text="Durée de l'emprunt (jours):").pack()
        entre_semaines_emprunt = Entry(emprunt)
        entre_semaines_emprunt.pack()

        Button(emprunt, text="Ajouter l'emprunt", command=ajouter_emprunt).pack()
        Button(emprunt, text="Retour", command=afficher_page_principale).pack()
    
    if infos_ajoute_emprunt == False:
        infos_ajouter_emprunt()
        infos_ajoute_emprunt = True

    entre_isbn_emprunt.delete(0, END)
    entre_date_emprunt.delete(0, END)

    entre_isbn_emprunt.insert(0, isbn)
    entre_date_emprunt.insert(0, date_ajd)

def ajouter_livre():
    titre = entre_titre.get()
    annee = entre_annee.get()
    auteur = liste_auteurs.get()[0]
    isbn = entre_isbn.get()
    resume = entre_resume.get()
    nbm_page = entre_page.get()
    couverture = entre_couverture.get()

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM Livres WHERE isbn = ?", (isbn,))
    count = cursor.fetchone()[0]

    cursor.close()
    conn.close()

    if count > 0:
            messagebox.showinfo("Erreur", "Le livre est déjà présent dans la bdd.")
            return afficher_page_principale()

    if len(titre) == 0:
        messagebox.showerror("Erreur", "Aucun titre.")
        return
    if len(annee) == 0:
        messagebox.showerror("Erreur", "Aucune année.")
        return
    if len(auteur) == 0:
        messagebox.showerror("Erreur", "Aucun auteur.")
        return
    if len(isbn) == 0:
        messagebox.showerror("Erreur", "Aucun isbn.")
        return
    
    try:
        datetime.datetime.strptime(annee, "%Y-%m-%d")
    except ValueError:
        messagebox.showerror("Erreur", "Incorrect data format, should be YYYY-MM-DD")
        return
    
    if not isbn.isdigit():
        messagebox.showerror("Erreur", "L'ISBN ne doit comporter que des numéros.")
        return
    elif len(isbn) != 13:
        messagebox.showerror("Erreur", "ISBN incorrect. L'ISBN doit comporter exactement 13 chiffres." + str(len(isbn)))
        return
    
    if len(nbm_page) == 0:
        messagebox.showerror("Erreur", "Veuillez ajouter le nombre de pages", len(isbn))
        return
    
    if len(resume) == 0:
        resume = None
    if len(couverture) == 0:
        couverture = None

    if auteur == "A":
        afficher_ajouter_auteur()
    
    else:
        conn = sqlite3.connect(bdd)
        cursor = conn.cursor()

        cursor.execute("INSERT INTO Livres(isbn, titre, annee, auteur_id, nbm_page, resume, couverture) VALUES (?, ?, ?, ?, ?, ?, ?)", (isbn, titre, annee, auteur, int(nbm_page), resume, couverture))
        conn.commit()

        cursor.close()
        conn.close()

        entre_titre.delete(0, END)
        entre_annee.delete(0, END)
        liste_auteurs.set("")
        entre_resume.delete(0, END)
        entre_isbn.delete(0, END)
        entre_page.delete(0, END)
        entre_couverture.delete(0, END)

        messagebox.showinfo("Succès", "Le livre a été ajouté avec succès!")

        afficher_page_principale()

def ajouter_livre_plus_auteur():
    nom = nom_auteur.get()
    biographie = biographie_auteur.get()

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()

    cursor.execute("INSERT INTO Auteurs(nom, biographie) VALUES (?, ?)", (nom, biographie))
    conn.commit()

    id_nouvel_auteur = cursor.lastrowid

    cursor.close()
    conn.close()
    
    messagebox.showinfo("Succès", "L'auteur' a été ajouté avec succès!")
    fenetre_nouvel_auteur.destroy()

    titre = entre_titre.get()
    annee = entre_annee.get()
    auteur = id_nouvel_auteur
    isbn = entre_isbn.get()
    resume = entre_resume.get()
    nbm_page = entre_page.get()
    couverture = entre_couverture.get()

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()

    cursor.execute("INSERT INTO Livres(isbn, titre, annee, auteur_id, nbm_page, resume, couverture) VALUES (?, ?, ?, ?, ?, ?, ?)", (isbn, titre, annee, auteur, nbm_page, resume, couverture))
    conn.commit()

    cursor.close()
    conn.close()

    entre_titre.delete(0, END)
    entre_annee.delete(0, END)
    liste_auteurs.set("")
    entre_resume.delete(0, END)
    entre_isbn.delete(0, END)
    entre_page.delete(0, END)
    entre_couverture.delete(0, END)

    messagebox.showinfo("Succès", "Le livre a été ajouté avec succès!")

    afficher_page_principale()

def ajouter_auteur():
    nom = nom_auteur.get()
    biographie = biographie_auteur.get()

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()

    cursor.execute("INSERT INTO Auteurs(nom, biographie) VALUES (?, ?)", (nom, biographie))
    conn.commit()

    cursor.close()
    conn.close()
    
    messagebox.showinfo("Succès", "L'auteur' a été ajouté avec succès!")
    fenetre_nouvel_auteur.destroy()

def supprimer_auteur():
    def supprimer_selection():
        conn = sqlite3.connect(bdd)
        cursor = conn.cursor()

        for item in tree.selection():
            auteur_id = tree.item(item, "values")[0]

            cursor.execute("SELECT COUNT(*) FROM Livres WHERE auteur_id = ?", (auteur_id,))
            compteur = cursor.fetchone()[0]

            if compteur > 0:
                messagebox.showerror("Erreur", "Impossible de supprimer l'auteur car il est associé à au moins un livre.")
                return
            else:
                cursor.execute("DELETE FROM Auteurs WHERE id=?", (auteur_id,))
                cursor.execute("UPDATE Auteurs SET id=id-1 WHERE id > ?", (auteur_id,))
                tree.delete(item)

        cursor.close()
        conn.commit()
        conn.close()
    
        messagebox.showinfo("Suppression", "Auteur sélectionnés supprimés avec succès!")
        fenetre_liste_livres.destroy()

    if bdd == "":
        return messagebox.showinfo("Erreur", "Aucune bdd ouverte.")

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM Auteurs")
    rows = cursor.fetchall()

    cursor.close()
    conn.commit()
    conn.close()
    
    fenetre_liste_livres = Toplevel()
    fenetre_liste_livres.title("Liste des Auteurs")
    
    tree = ttk.Treeview(fenetre_liste_livres, columns=("ID", "Nom", "Biographie"), show="headings")
    tree.pack(expand=True, fill="both")
    
    tree.heading("ID", text="ID")
    tree.heading("Nom", text="Nom")
    tree.heading("Biographie", text="Biographie")
    
    for row in rows:
        tree.insert("", "end", values=row)
    
    Button(fenetre_liste_livres, text="Supprimer sélection", command=supprimer_selection).pack()

def supprimer_livre():
    def supprimer_selection():
        conn = sqlite3.connect(bdd)
        cursor = conn.cursor()
    
        for item in tree.selection():
            livre_isbn = tree.item(item, "values")[0]
            cursor.execute("DELETE FROM Livres WHERE isbn=?", (livre_isbn,))
            tree.delete(item)
        cursor.close()
        conn.commit()
        conn.close()
    
        messagebox.showinfo("Suppression", "Livres sélectionnés supprimés avec succès!")
        fenetre_liste_livres.destroy()

    if bdd == "":
        return messagebox.showinfo("Erreur", "Aucune bdd ouverte.")

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM Livres")
    rows = cursor.fetchall()
    
    fenetre_liste_livres = Toplevel()
    fenetre_liste_livres.title("Liste des Livres")
    
    tree = ttk.Treeview(fenetre_liste_livres, columns=("Isbn", "Titre", "Année", "Auteur","Nombre de pages", "Résumé"), show="headings")
    tree.pack(expand=True, fill="both")
    
    tree.heading("Isbn", text="Isbn")
    tree.heading("Titre", text="Titre")
    tree.heading("Année", text="Année")
    tree.heading("Auteur", text="Auteur")
    tree.heading("Nombre de pages", text="Nombre de pages")
    tree.heading("Résumé", text="Résumé")
    
    for row in rows:
        tree.insert("", "end", values=row)
    
    Button(fenetre_liste_livres, text="Supprimer sélection", command=supprimer_selection).pack()

def supprimer_emprunter():
    def supprimer_selection():
        conn = sqlite3.connect(bdd)
        cursor = conn.cursor()

        for item in tree.selection():
            livre_isbn = tree.item(item, "values")[0]

            cursor.execute("DELETE FROM Emprunts WHERE livre_isbn=?", (livre_isbn,))
            tree.delete(item)

        cursor.close()
        conn.commit()
        conn.close()
    
        messagebox.showinfo("Suppression", "Emprunts sélectionnés supprimés avec succès!")
        fenetre_liste_emprunts.destroy()

    if bdd == "":
        return messagebox.showinfo("Erreur", "Aucune bdd ouverte.")

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM Emprunts")
    rows = cursor.fetchall()

    cursor.close()
    conn.commit()
    conn.close()
    
    fenetre_liste_emprunts = Toplevel()
    fenetre_liste_emprunts.title("Liste des Emprunts")
    
    tree = ttk.Treeview(fenetre_liste_emprunts, columns=("livre_isbn", "nom_emprunteur", "numero_tel", "date_emprunt", "semaines_emprunt", "date_retour"), show="headings")
    tree.pack(expand=True, fill="both")
    
    tree.heading("livre_isbn", text="livre_isbn")
    tree.heading("nom_emprunteur", text="nom_emprunteur")
    tree.heading("numero_tel", text="numero_tel")
    tree.heading("date_emprunt", text="date_emprunt")
    tree.heading("semaines_emprunt", text="semaines_emprunt")
    tree.heading("date_retour", text="date_retour")
    
    for row in rows:
        tree.insert("", "end", values=row)
    
    Button(fenetre_liste_emprunts, text="Supprimer sélection", command=supprimer_selection).pack()

def modifier_auteur():
    def afficher_modifier_auteur():
        def modifier_selection():
            nom = nom_modifier.get()
            biographie = biographie_modifier.get()

            conn = sqlite3.connect(bdd)
            cursor = conn.cursor()

            auteur_id = tree.item(tree.selection(), "values")[0]
            cursor.execute("UPDATE Auteurs SET nom=?, biographie=? WHERE id=?", (nom, biographie, auteur_id))

            conn.commit()
            cursor.close()
            conn.close()
        
            messagebox.showinfo("Modification", "Auteur sélectionné modifié avec succès!")
            fenetre_liste_auteurs.destroy()
        
        if not tree.selection():
            messagebox.showwarning("Attention", "Veuillez sélectionner un auteur à modifier.")
            return
        
        fenetre_modifier_auteur = Toplevel()
        fenetre_modifier_auteur.title("Modifier Auteur")

        selected_item = tree.selection()[0]
        auteur_data = tree.item(selected_item, "values")

        nom_modifier = Label(fenetre_modifier_auteur, text="Nom:").pack()
        nom_modifier = Entry(fenetre_modifier_auteur)
        nom_modifier.insert(0, auteur_data[1])
        nom_modifier.pack()

        biographie_modifier = Label(fenetre_modifier_auteur, text="Biographie:").pack()
        biographie_modifier = Entry(fenetre_modifier_auteur)
        biographie_modifier.insert(0, auteur_data[2])
        biographie_modifier.pack()

        Button(fenetre_modifier_auteur, text="Valider", command=modifier_selection).pack()

    if bdd == "":
        return messagebox.showinfo("Erreur", "Aucune bdd ouverte.")

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM Auteurs")
    rows = cursor.fetchall()

    conn.commit()
    cursor.close()
    conn.close()
    
    fenetre_liste_auteurs = Toplevel()
    fenetre_liste_auteurs.title("Liste des Auteurs")
    
    tree = ttk.Treeview(fenetre_liste_auteurs, columns=("ID", "Nom", "Biographie"), show="headings", selectmode="browse")
    tree.pack(expand=True, fill="both")
    
    tree.heading("ID", text="ID")
    tree.heading("Nom", text="Nom")
    tree.heading("Biographie", text="Biographie")
    
    for row in rows:
        tree.insert("", "end", values=row)
    
    Button(fenetre_liste_auteurs, text="Modifier sélection", command=afficher_modifier_auteur).pack()

def modifier_livre():
    def afficher_modifier_livre():
        def modifier_selection():
            titre = titre_modifier.get()
            annee = annee_modifier.get()
            auteur = int(auteur_modifier.get()[0])
            nbm_page = nbm_page_modifier.get()
            resume = resume_modifier.get()
            couverture = couverture_modifier.get()

            conn = sqlite3.connect(bdd)
            cursor = conn.cursor()

            cursor.execute("UPDATE Livres SET titre=?, annee=?, auteur_id=?, nbm_page=?, resume=?, couverture=? WHERE isbn=?", (titre, annee, auteur, nbm_page, resume, couverture, donnees_livres[0]))

            conn.commit()
            cursor.close()
            conn.close()
        
            messagebox.showinfo("Modification", "Livre sélectionné modifié avec succès!")
            fenetre_liste_livres.destroy()
            fenetre_modifier_livre.destroy()
        
        if not tree.selection():
            messagebox.showwarning("Attention", "Veuillez sélectionner un auteur à modifier.")
            return

        fenetre_modifier_livre = Toplevel()
        fenetre_modifier_livre.title("Modifier Livre")

        selected_item = tree.selection()[0]
        donnees_livres = tree.item(selected_item, "values")

        titre_modifier = Label(fenetre_modifier_livre, text="Titre:").pack()
        titre_modifier = Entry(fenetre_modifier_livre)
        titre_modifier.insert(0, donnees_livres[1])
        titre_modifier.pack()

        annee_modifier = Label(fenetre_modifier_livre, text="Date de parution:").pack()
        annee_modifier = Entry(fenetre_modifier_livre)
        annee_modifier.insert(0, donnees_livres[2])
        annee_modifier.pack()

        auteur_modifier = Label(fenetre_modifier_livre, text="Auteur:").pack()
        auteur_modifier = ttk.Combobox(fenetre_modifier_livre, values=id_noms_prenoms_auteurs, state="readonly")
        auteur_modifier.current(int(donnees_livres[3])-1)
        auteur_modifier.pack()

        nbm_page_modifier = Label(fenetre_modifier_livre, text="Nombre de pages:").pack()
        nbm_page_modifier = Entry(fenetre_modifier_livre)
        nbm_page_modifier.insert(0, donnees_livres[4])
        nbm_page_modifier.pack()

        resume_modifier = Label(fenetre_modifier_livre, text="Résumé:").pack()
        resume_modifier = Entry(fenetre_modifier_livre)
        resume_modifier.insert(0, donnees_livres[5])
        resume_modifier.pack()

        couverture_modifier = Label(fenetre_modifier_livre, text="Couverture:").pack()
        couverture_modifier = Entry(fenetre_modifier_livre)
        couverture_modifier.insert(0, donnees_livres[6])
        couverture_modifier.pack()

        Button(fenetre_modifier_livre, text="Valider", command=modifier_selection).pack()

    if bdd == "":
        return messagebox.showinfo("Erreur", "Aucune bdd ouverte.")

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM Livres")
    rows_livres = cursor.fetchall()
    cursor.execute("SELECT id, nom FROM Auteurs")
    rows_auteurs = cursor.fetchall()

    conn.commit()
    cursor.close()
    conn.close()

    id_noms_prenoms_auteurs = [row for row in rows_auteurs]
    
    fenetre_liste_livres = Toplevel()
    fenetre_liste_livres.title("Liste des Livres")
    
    tree = ttk.Treeview(fenetre_liste_livres, columns=("Isbn", "Titre", "Année", "Auteur","Nombre de pages", "Résumé"), show="headings", selectmode="browse")
    tree.pack(expand=True, fill="both")
    
    tree.heading("Isbn", text="Isbn")
    tree.heading("Titre", text="Titre")
    tree.heading("Année", text="Année")
    tree.heading("Auteur", text="Auteur")
    tree.heading("Nombre de pages", text="Nombre de pages")
    tree.heading("Résumé", text="Résumé")
    
    for row in rows_livres:
        tree.insert("", "end", values=row)
    
    Button(fenetre_liste_livres, text="Modifier sélection", command=afficher_modifier_livre).pack()

def modifier_emprunter():
    def afficher_modifier_emprunter():
        def modifier_selection():
            livre_isbn = livre_isbn_modifier.get()
            nom_emprunteur = nom_emprunteur_modifier.get()
            num_telephone = num_telephone_modifier.get()

            conn = sqlite3.connect(bdd)
            cursor = conn.cursor()

            isbn_de_base = tree.item(tree.selection(), "values")[0]
            cursor.execute("UPDATE Emprunts SET livre_isbn=?, nom_emprunteur=?, numero_tel=? WHERE livre_isbn=?", (livre_isbn, nom_emprunteur, num_telephone, isbn_de_base))

            conn.commit()
            cursor.close()
            conn.close()
        
            messagebox.showinfo("Modification", "Emprunt sélectionné modifié avec succès!")
            fenetre_liste_emprunts.destroy()
        
        if not tree.selection():
            messagebox.showwarning("Attention", "Veuillez sélectionner un auteur à modifier.")
            return
        
        fenetre_liste_emprunts = Toplevel()
        fenetre_liste_emprunts.title("Modifier Emprunts")

        selected_item = tree.selection()[0]
        emprunt_data = tree.item(selected_item, "values")

        livre_isbn_modifier = Label(fenetre_liste_emprunts, text="Isbn du livre:").pack()
        livre_isbn_modifier = Entry(fenetre_liste_emprunts)
        livre_isbn_modifier.insert(0, emprunt_data[0])
        livre_isbn_modifier.pack()

        nom_emprunteur_modifier = Label(fenetre_liste_emprunts, text="Nom de l'emprunteur:").pack()
        nom_emprunteur_modifier = Entry(fenetre_liste_emprunts)
        nom_emprunteur_modifier.insert(0, emprunt_data[1])
        nom_emprunteur_modifier.pack()

        num_telephone_modifier = Label(fenetre_liste_emprunts, text="Numéro de téléphone:").pack()
        num_telephone_modifier = Entry(fenetre_liste_emprunts)
        num_telephone_modifier.insert(0, emprunt_data[2])
        num_telephone_modifier.pack()

        Button(fenetre_liste_emprunts, text="Valider", command=modifier_selection).pack()

    if bdd == "":
        return messagebox.showinfo("Erreur", "Aucune bdd ouverte.")

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM Emprunts")
    rows = cursor.fetchall()

    conn.commit()
    cursor.close()
    conn.close()
    
    fenetre_liste_emprunts = Toplevel()
    fenetre_liste_emprunts.title("Liste des Emprunts")
    
    tree = ttk.Treeview(fenetre_liste_emprunts, columns=("livre_isbn", "nom_emprunteur", "numero_tel", "date_emprunt", "semaines_emprunt", "date_retour"), show="headings", selectmode="browse")
    tree.pack(expand=True, fill="both")
    
    tree.heading("livre_isbn", text="livre_isbn")
    tree.heading("nom_emprunteur", text="nom_emprunteur")
    tree.heading("date_emprunt", text="date_emprunt")
    tree.heading("semaines_emprunt", text="semaines_emprunt")
    tree.heading("date_retour", text="date_retour")
    
    for row in rows:
        tree.insert("", "end", values=row)
    
    Button(fenetre_liste_emprunts, text="Modifier sélection", command=afficher_modifier_emprunter).pack()

def ajouter_emprunt():
    global lecture_isbn

    entre_isbn = entre_isbn_emprunt.get()
    entre_nom = entre_nom_emprunteur.get()
    entre_numero = entre_numero_tel.get()
    entre_date = entre_date_emprunt.get()
    entre_semaines = entre_semaines_emprunt.get()

    entre_date_retour = datetime.datetime.strptime(entre_date, "%Y-%m-%d")
    entre_date_retour = entre_date_retour + timedelta(days=int(entre_semaines))
    entre_date_retour = entre_date_retour.strftime("%Y-%m-%d")

    if len(entre_numero) != 10:
        messagebox.showerror("Erreur", "Numéro de téléphone non valide.")
        return

    try:
        datetime.datetime.strptime(entre_date, "%Y-%m-%d")
    except ValueError:
        messagebox.showerror("Erreur", "Incorrect data format, should be YYYY-MM-DD")
        return

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()

    cursor.execute("INSERT INTO Emprunts(livre_isbn, nom_emprunteur, numero_tel, date_emprunt, semaines_emprunt, date_retour) VALUES (?, ?, ?, ?, ?, ?)", (entre_isbn, entre_nom, entre_numero, entre_date, entre_semaines, entre_date_retour))
    conn.commit()

    cursor.close()
    conn.close()
    
    messagebox.showinfo("Succès", "L'emprunt a bien été enregistré!")

    entre_isbn_emprunt.delete(0, END)
    entre_nom_emprunteur.delete(0, END)
    entre_numero_tel.delete(0, END)
    entre_date_emprunt.delete(0, END)
    entre_semaines_emprunt.delete(0, END)

    afficher_page_principale()

def rendre_livre():
    global lecture_isbn

    isbn = isbn_pour_emprunt

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()

    cursor.execute("SELECT emprunt FROM Livres WHERE isbn = ?", (isbn,))
    dispo = cursor.fetchone()

    cursor.close()
    conn.close()

    if dispo[0] == 0:
        messagebox.showinfo("Erreur", "Le livre n'est pas emprunté")
        return

    conn = sqlite3.connect(bdd)
    cursor = conn.cursor()

    cursor.execute("DELETE FROM Emprunts WHERE livre_isbn = ?", (isbn,))
    conn.commit()

    cursor.close()
    conn.close()

    messagebox.showinfo("Succès", "Livre rendu avec succès !")

fenetre_principale = Tk()
fenetre_principale.title("BILBIO")
fenetre_principale.state('zoomed')

Label(fenetre_principale, text="BIBLIO", font=("Helvetica", 50)).pack()

page_principale = Frame(fenetre_principale)
ajouter = Frame(fenetre_principale)
modifier = Frame(fenetre_principale)
supprimer = Frame(fenetre_principale)
emprunt = Frame(fenetre_principale)

page_principale.pack()

menubar = Menu(fenetre_principale)

menu1 = Menu(menubar, tearoff=0)
menu1.add_command(label="Ouvrir une bdd", command=ouvrir_fichier)
menu1.add_command(label="Créer une bdd", command=nom_bdd)
menu1.add_separator()
menu1.add_command(label="Quitter", command=fenetre_principale.quit)
menubar.add_cascade(label="Fichier", menu=menu1)

menu2 = Menu(menubar, tearoff=0)
menu2.add_command(label="Ajouter", command=afficher_ajouter_livre)
menu2.add_command(label="Modifier", command=afficher_modifier)
menu2.add_command(label="Supprimer", command=afficher_supprimer)
menubar.add_cascade(label="Editer", menu=menu2)

menu3 = Menu(menubar, tearoff=0)
menu3.add_command(label="A propos", command=fenêtre_a_propos)
menubar.add_cascade(label="Aide", menu=menu3)

fenetre_principale.config(menu=menubar)

ouvrir = Button(page_principale, text="Ouvrir une bdd", command=ouvrir_fichier)
ouvrir.grid(row=0, column=0, padx=10, pady=10)
creer = Button(page_principale, text="Créer une bdd", command=nom_bdd)
creer.grid(row=0, column=1, padx=10, pady=10)

fenetre_principale.mainloop()